int main () {
  bool x = true;
  x++;
  return 0;
}
