int main() {
	{
		int x;
	}
	x = 4;
	return 2;
}
