int main() {
        int x;
        int x;
	return 0 ;
}
