int main() {
	int x, y;
	{
		int y;
	}
	int x;
	return 0;
}
