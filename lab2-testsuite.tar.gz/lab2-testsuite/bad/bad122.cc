int main () {
  int x = true / 5;
  return x;
}
