int main () {
  int x = false || 45;
  return 0;
}
