void foo() {
  return 56;
}

int main () {
  foo();
  return 5;
}