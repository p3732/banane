int main() {
	int x, y;
	{
		int z;
	}
	int y;
	return 0;
}
