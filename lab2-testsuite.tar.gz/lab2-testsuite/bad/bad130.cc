int main () {
	while (3 == 3.0) {}	
	return 0;
}
