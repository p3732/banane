int main () {
  return test();
}

int test() {
  return 32;
}
